package com.example.foodrunner2.model

data class RestaurantsMenu (
    val id:String,
    val resid:String,
    val name:String,
    val cost:String
)
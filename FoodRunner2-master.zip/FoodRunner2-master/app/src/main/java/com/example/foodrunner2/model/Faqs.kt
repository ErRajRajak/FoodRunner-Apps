package com.example.foodrunner2.model

data class Faqs(
    var question :String,
    var answer : String
)